exported graph path: frozen_inference_graph.pb
submission.csv: submission.csv
Modified codes: hackathon_baseline.config
